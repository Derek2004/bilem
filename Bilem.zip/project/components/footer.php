<!-- footer section starts  -->

<footer class="footer">

   <section class="flex">

      <div class="box">
         <a href="tel:0720484284"><i class="fas fa-phone"></i><span>0720484284</span></a>
         <a href="tel:0732308254"><i class="fas fa-phone"></i><span>0732308254</span></a>
         <a href="mailto:info@bilemconsoltants.co.ke"><i class="fas fa-envelope"></i><span>info@bilemconsoltants.co.ke</span></a>
         <a href="#"><i class="fas fa-map-marker-alt"></i><span>
            Rose Avenue Off Lenana Rd Kilimani
            P.O Box 27794-00100,Nairobi.
         </span></a>
      </div>

      


      <div class="box">
         <a href="home.php"><span>home</span></a>
         <a href="about.php"><span>about</span></a>
         <a href="contact.php"><span>contact</span></a>
         <a href="listings.php"><span>all listings</span></a>
         <a href="saved.php"><span>saved properties</span></a>
      </div>

      <div class="wrapper">
        <div> <a href="#"><span>facebook</span><i class="fab fa-facebook-f"></i></a>
         <a href="#"><span>twitter</span><i class="fab fa-twitter"></i></a>
         <a href="#"><span>linkedin</span><i class="fab fa-linkedin"></i></a>
         <a href="#"><span>instagram</span><i class="fab fa-instagram"></i></a>

      </div>

   </section>

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span></span> | all rights reserved</div>

</footer>

<!-- footer section ends -->